package utils;

import fr.dauphine.ds.filesystem.DauphineSystemFileSystem;

import java.util.HashMap;
import java.util.Map;

import java.io.FileNotFoundException;

public class DauphineSystemFileSystemMock extends DauphineSystemFileSystem {

    private final String fixedDate = "2019-01-01";

    private final Map<String, String> pathToContent = new HashMap<>();
    private final Map<String, String> pathToDate = new HashMap<>();

    @Override
    public boolean exist(String path) {
        return pathToContent.containsKey(path);
    }

    @Override
    public String getCreationDate(String path) {
        return pathToDate.get(path);
    }

    @Override
    public String getFile(String path) {
        return pathToContent.get(path);
    }

    private void append(String path, String content) {
        String oldContent = pathToContent.get(path);
        pathToContent.put(path, oldContent+"\n"+content);
    }

    private void forceWrite(String path, String content) {
        pathToContent.put(path, content);
        pathToDate.put(path, fixedDate);
    }

    @Override
    public void addFile(String path, String contents, int mode) {
        if ( mode == OVERWRITE_MODE )  forceWrite(path, contents);
        else if ( mode == APPEND_MODE && exist(path) )  append(path, contents);
        else if ( mode == APPEND_MODE && !exist(path) ) forceWrite(path, contents);
        else if ( mode == IGNORE_MODE  ) ; // do nothing
        else throw new IllegalArgumentException("probleme avec la valeur de mode");
    }
}
