import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import fr.dauphine.ds.filesystem.DauphineSystemFileSystem;
import fr.dauphine.sip.io.SIPIO;
import utils.DauphineSystemFileSystemMock;

class SIPIOTest {

    @Test
    void testReadFile() {
        DauphineSystemFileSystemMock mockFS = new DauphineSystemFileSystemMock();
        mockFS.addFile("test", "coucou", DauphineSystemFileSystem.OVERWRITE_MODE);
        SIPIO io = new SIPIO(mockFS);

        // good name, good date
        assert(io.readFile("test", "2018-01-02")=="coucou");
        // good name, bad date
        assert(io.readFile("test", "2020-01-02")==null);
        //bad name
        assert(io.readFile("test2", "2020-01-02")==null);
    }

    @Test
    void testExistFile() {
        DauphineSystemFileSystemMock mockFS = new DauphineSystemFileSystemMock();
        mockFS.addFile("test", "coucou", DauphineSystemFileSystem.OVERWRITE_MODE);
        SIPIO io = new SIPIO(mockFS);

        // good name, good date
        boolean res = io.exist("test", "2018-01-02");
        assert(io.exist("test", "2018-01-02"));
        // good name, bad date
        assert(!io.exist("test", "2020-01-02"));
        //bad name
        assert(!io.exist("test2", "2020-01-02"));
    }

    @Test
    void testAddFile() {
        DauphineSystemFileSystemMock mockFS = new DauphineSystemFileSystemMock();
        SIPIO io = new SIPIO(mockFS);
        io.addFile("test", "coucou");

        assert(mockFS.exist("test"));
        assert(mockFS.getFile("test")=="coucou");
    }

    // etc...
}
