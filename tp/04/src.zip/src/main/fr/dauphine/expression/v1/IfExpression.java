package fr.dauphine.expression.v1;

public interface IfExpression {
    default public IfExpression expIf(boolean b, String val) {
        throw new IllegalStateException();
    }

    default public IfExpression expElseIf(boolean b, String val){
        throw new IllegalStateException();
    }

    default public String expElse(String val){
        throw new IllegalStateException();
    }

    /**
     * permet de cacher totalement l'impementation de IfExpression
     * bcq plus propre qu'oobliger l utilisateur à faire lui meme le new
     * @return
     */
    public static IfExpression startExp() {
        return new BeforeIf();
    }
}
