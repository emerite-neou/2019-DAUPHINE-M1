package fr.dauphine.expression.v1;

public class BeforeIf implements IfExpression {
    @Override
    public IfExpression expIf(boolean b, String val) {
        return new AfterIf(b, val);
    }
}
