package fr.dauphine.expression.v1;

public class AfterIf implements IfExpression {

    private boolean previsouBoolean;
    private String previousVal;

    public AfterIf(boolean previsouBoolean, String previousVal) {
        this.previsouBoolean = previsouBoolean;
        this.previousVal = previousVal;
    }

    @Override
    public IfExpression expElseIf(boolean b, String val) {
        if (!previsouBoolean) {
            previsouBoolean = b;
            previousVal = val;
        }
        return this;
    }

    /**
     * autre solution possible pour expElseIf
     * metter final pour les champs si on prefere celle la
     */
    public IfExpression expElseIf2(boolean b, String val) {
        if (previsouBoolean) return this;
        else return new AfterIf(b, val);
    }

    @Override
    public String expElse(String val) {
        if (previsouBoolean) return previousVal;
        else return val;
    }
}
