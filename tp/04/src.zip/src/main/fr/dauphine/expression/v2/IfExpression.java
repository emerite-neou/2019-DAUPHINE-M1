package fr.dauphine.expression.v2;

/**
 * avec des class internes
 * on peut faire des classes internes ici (malgres la taille de AfterIf et que ce n'est pas un interface habituel)
 * car on peut considere ce package "fini": l interface ne sera implementer par personne d autres
 */
public interface IfExpression {
    default public IfExpression expIf(boolean b, String val) {
        throw new IllegalStateException();
    }

    default public IfExpression expElseIf(boolean b, String val){
        throw new IllegalStateException();
    }

    default public String expElse(String val){
        throw new IllegalStateException();
    }

    public class BeforeIf implements IfExpression {
        @Override
        public IfExpression expIf(boolean b, String val) {
            return new AfterIf(b, val);
        }
    }

    public class AfterIf implements IfExpression {

        private boolean previsouBoolean;
        private String previousVal;

        public AfterIf(boolean previsouBoolean, String previousVal) {
            this.previsouBoolean = previsouBoolean;
            this.previousVal = previousVal;
        }

        @Override
        public IfExpression expElseIf(boolean b, String val) {
            if (!previsouBoolean) {
                previsouBoolean = b;
                previousVal = val;
            }
            return this;
        }

        /**
         * autre solution possible pour expElseIf
         * metter final pour les champs si on prefere celle la
         */
        public IfExpression expElseIf2(boolean b, String val) {
            if (previsouBoolean) return this;
            else return new AfterIf(b, val);
        }

        @Override
        public String expElse(String val) {
            if (previsouBoolean) return previousVal;
            else return val;
        }
    }

    /**
     * OBLIGATOIRE si on fait des class internes
     * @return
     */
    public static IfExpression startExp() {
        return new BeforeIf();
    }
}
